export class Employee {    
    public id: string;
    public name : string;
    public type: string;
    public workingDays: number;
    public vacations: number;
    constructor(){}
 }
